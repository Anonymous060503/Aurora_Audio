import subprocess
import sys
import pkg_resources
from concurrent.futures import ThreadPoolExecutor

def install_package(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

def check_and_install():
    with open("requirements.txt") as f:
        required = f.read().splitlines()

    installed = {pkg.key for pkg in pkg_resources.working_set}
    missing = []

    for req in required:
        if not req.strip():
            continue
        pkg_name = req.strip().split("==")[0].lower()
        if pkg_name not in installed:
            missing.append(req.strip())

    if missing:
        print(f"📦 Installing missing packages: {missing}")
        with ThreadPoolExecutor() as executor:
            executor.map(install_package, missing)
    else:
        print("✅ All dependencies are already installed.")

if __name__ == "__main__":
    check_and_install()