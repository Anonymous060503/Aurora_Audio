# aurora/database/blacklist.py

"""
Handles operations related to blacklisted users or groups.
Used to restrict access or prevent misuse.
"""

from aurora.database import db

# MongoDB collection reference
blacklist_collection = db["blacklist"]

async def add_to_blacklist(entity_id: int) -> bool:
    """
    Add a user or group to the blacklist.
    """
    exists = await blacklist_collection.find_one({"entity_id": entity_id})
    if exists:
        return False  # Already blacklisted
    await blacklist_collection.insert_one({"entity_id": entity_id})
    return True

async def remove_from_blacklist(entity_id: int) -> bool:
    """
    Remove a user or group from the blacklist.
    """
    result = await blacklist_collection.delete_one({"entity_id": entity_id})
    return result.deleted_count > 0

async def is_blacklisted(entity_id: int) -> bool:
    """
    Check if a user or group is blacklisted.
    """
    return await blacklist_collection.find_one({"entity_id": entity_id}) is not None

async def get_all_blacklisted() -> list:
    """
    Retrieve all blacklisted IDs.
    """
    cursor = blacklist_collection.find({})
    return [doc["entity_id"] async for doc in cursor]