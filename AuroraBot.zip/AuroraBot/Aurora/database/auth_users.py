# aurora/database/auth_users.py

"""
Handles storage and retrieval of authorized users for command access.
"""

from aurora.database import db

# MongoDB collection reference
auth_users_collection = db["auth_users"]

async def add_authorized_user(user_id: int) -> bool:
    """
    Add a user to the authorized users list.
    """
    user = await auth_users_collection.find_one({"user_id": user_id})
    if user:
        return False  # Already exists
    await auth_users_collection.insert_one({"user_id": user_id})
    return True

async def remove_authorized_user(user_id: int) -> bool:
    """
    Remove a user from the authorized users list.
    """
    result = await auth_users_collection.delete_one({"user_id": user_id})
    return result.deleted_count > 0

async def is_user_authorized(user_id: int) -> bool:
    """
    Check if the user is authorized.
    """
    user = await auth_users_collection.find_one({"user_id": user_id})
    return user is not None

async def get_all_authorized_users() -> list:
    """
    Get a list of all authorized user IDs.
    """
    cursor = auth_users_collection.find({})
    return [doc["user_id"] async for doc in cursor]