# aurora/database/loop_config.py

"""
Manages loop playback settings per group chat.
"""

from aurora.database import db

# MongoDB collection for loop config
loop_collection = db["loop_config"]

async def enable_loop(chat_id: int) -> None:
    """
    Enable loop mode for a specific group.
    """
    await loop_collection.update_one(
        {"chat_id": chat_id},
        {"$set": {"loop_enabled": True}},
        upsert=True
    )

async def disable_loop(chat_id: int) -> None:
    """
    Disable loop mode for a specific group.
    """
    await loop_collection.update_one(
        {"chat_id": chat_id},
        {"$set": {"loop_enabled": False}},
        upsert=True
    )

async def is_loop_enabled(chat_id: int) -> bool:
    """
    Check whether loop is enabled for a group.
    """
    result = await loop_collection.find_one({"chat_id": chat_id})
    return result.get("loop_enabled", False) if result else False

async def get_all_loop_enabled_chats() -> list:
    """
    Returns a list of chat IDs with loop mode enabled.
    """
    cursor = loop_collection.find({"loop_enabled": True})
    return [doc["chat_id"] async for doc in cursor]