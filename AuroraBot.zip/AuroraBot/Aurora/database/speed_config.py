# aurora/database/speed_config.py

"""
Handles playback speed settings per group.
"""

from aurora.database import db

# MongoDB collection for speed config
speed_collection = db["speed_config"]

async def set_playback_speed(chat_id: int, speed: float) -> None:
    """
    Set custom playback speed for a specific group.
    """
    await speed_collection.update_one(
        {"chat_id": chat_id},
        {"$set": {"speed": speed}},
        upsert=True
    )

async def get_playback_speed(chat_id: int) -> float:
    """
    Get the current playback speed for a group.
    Defaults to 1.0x if not set.
    """
    result = await speed_collection.find_one({"chat_id": chat_id})
    return result.get("speed", 1.0) if result else 1.0

async def reset_playback_speed(chat_id: int) -> None:
    """
    Reset playback speed to default (1.0x).
    """
    await speed_collection.delete_one({"chat_id": chat_id})

async def get_all_custom_speed_chats() -> list:
    """
    Get list of all chat_ids with custom playback speed.
    """
    cursor = speed_collection.find({})
    return [doc["chat_id"] async for doc in cursor]