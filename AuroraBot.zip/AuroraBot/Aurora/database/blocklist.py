# aurora/database/blocklist.py

"""
Handles permanently blocked users or groups.
These entities are completely restricted from interacting with the bot.
"""

from aurora.database import db

# MongoDB collection reference
blocklist_collection = db["blocklist"]

async def add_to_blocklist(entity_id: int) -> bool:
    """
    Add a user or group to the blocklist.
    """
    exists = await blocklist_collection.find_one({"entity_id": entity_id})
    if exists:
        return False  # Already blocked
    await blocklist_collection.insert_one({"entity_id": entity_id})
    return True

async def remove_from_blocklist(entity_id: int) -> bool:
    """
    Remove a user or group from the blocklist.
    """
    result = await blocklist_collection.delete_one({"entity_id": entity_id})
    return result.deleted_count > 0

async def is_blocked(entity_id: int) -> bool:
    """
    Check if a user or group is blocked.
    """
    return await blocklist_collection.find_one({"entity_id": entity_id}) is not None

async def get_all_blocked() -> list:
    """
    Retrieve all blocked IDs.
    """
    cursor = blocklist_collection.find({})
    return [doc["entity_id"] async for doc in cursor]