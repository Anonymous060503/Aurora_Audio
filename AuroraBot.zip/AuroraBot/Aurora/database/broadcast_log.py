# aurora/database/broadcast_log.py

"""
Logs broadcast messages sent by the bot (admin/global).
Helps to avoid repeat sending and track delivery status.
"""

from aurora.database import db
from datetime import datetime

# MongoDB collection
broadcast_collection = db["broadcast_log"]


async def log_broadcast(message_id: int, sender_id: int, content: str) -> None:
    """
    Store a new broadcast log entry.
    """
    await broadcast_collection.insert_one({
        "message_id": message_id,
        "sender_id": sender_id,
        "content": content,
        "timestamp": datetime.utcnow()
    })


async def get_broadcast_logs(limit: int = 10) -> list:
    """
    Retrieve the latest N broadcast logs.
    """
    cursor = broadcast_collection.find().sort("timestamp", -1).limit(limit)
    return [doc async for doc in cursor]


async def delete_broadcast_log(message_id: int) -> None:
    """
    Delete a specific broadcast log entry by message ID.
    """
    await broadcast_collection.delete_one({"message_id": message_id})


async def clear_broadcast_logs() -> None:
    """
    Clear all broadcast log entries.
    """
    await broadcast_collection.delete_many({})