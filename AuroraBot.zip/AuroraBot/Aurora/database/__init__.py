# aurora/database/__init__.py

"""
Initialize MongoDB connection and export the database instance
to be used across the project.
"""

from motor.motor_asyncio import AsyncIOMotorClient
from aurora.config import MONGO_URI

# MongoDB Client initialization
try:
    mongo_client = AsyncIOMotorClient(MONGO_URI)
    db = mongo_client["AuroraBot"]
    print("✅ Connected to MongoDB.")
except Exception as e:
    print(f"❌ Failed to connect to MongoDB: {e}")
    raise SystemExit("Database connection failed. Shutting down.")