# aurora/database/whitelist.py

"""
Handles operations related to whitelisted users or groups.
Used to allow special access or privileged usage.
"""

from aurora.database import db

# MongoDB collection reference
whitelist_collection = db["whitelist"]

async def add_to_whitelist(entity_id: int) -> bool:
    """
    Add a user or group to the whitelist.
    """
    exists = await whitelist_collection.find_one({"entity_id": entity_id})
    if exists:
        return False  # Already whitelisted
    await whitelist_collection.insert_one({"entity_id": entity_id})
    return True

async def remove_from_whitelist(entity_id: int) -> bool:
    """
    Remove a user or group from the whitelist.
    """
    result = await whitelist_collection.delete_one({"entity_id": entity_id})
    return result.deleted_count > 0

async def is_whitelisted(entity_id: int) -> bool:
    """
    Check if a user or group is whitelisted.
    """
    return await whitelist_collection.find_one({"entity_id": entity_id}) is not None

async def get_all_whitelisted() -> list:
    """
    Retrieve all whitelisted IDs.
    """
    cursor = whitelist_collection.find({})
    return [doc["entity_id"] async for doc in cursor]