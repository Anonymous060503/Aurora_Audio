import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    # Telegram bot token
    BOT_TOKEN = os.getenv("BOT_TOKEN")

    # Telegram API credentials (for Pyrogram client)
    API_ID = int(os.getenv("API_ID", "0"))
    API_HASH = os.getenv("API_HASH")

    # MongoDB URI for database connections
    MONGO_URI = os.getenv("MONGO_URI")

    # Bot owner ID (for full admin access)
    OWNER_ID = int(os.getenv("OWNER_ID", "0"))

    # Session string (optional if using userbot features)
    SESSION_STRING = os.getenv("SESSION_STRING", None)

    # Logging and debug toggle
    DEBUG_MODE = bool(os.getenv("DEBUG_MODE", False))

    # Optional: Additional configuration options
    DOWNLOAD_PATH = "./downloads"
    TEMP_PATH = "./temp"

    # Optional: Logging level
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# Access config anywhere using: from aurora.config import Config