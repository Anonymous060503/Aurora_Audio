"""
AuroraBot - Initialization file for the core package
"""

from aurora.config import Config
import logging
import os

# Set up basic logging config
LOG_LEVEL = logging.DEBUG if Config.DEBUG_MODE else logging.INFO

logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)
logger.info("AuroraBot package initialized.")

# Ensure necessary directories exist
os.makedirs(Config.DOWNLOAD_PATH, exist_ok=True)
os.makedirs(Config.TEMP_PATH, exist_ok=True)