# aurora/handlers/auth_handler.py

from pyrogram.types import Message
from aurora.database.auth_users import is_user_authorized


async def check_auth(message: Message) -> bool:
    """
    Check if the user is authorized to use the bot commands.
    
    Args:
        message (Message): The incoming message from the user.
    
    Returns:
        bool: True if authorized, False otherwise.
    """
    user_id = message.from_user.id if message.from_user else None

    if not user_id:
        await message.reply_text("⚠️ Cannot verify user identity.")
        return False

    if not await is_user_authorized(user_id):
        await message.reply_text("⛔ You are not authorized to use this command.")
        return False

    return True