# aurora/handlers/__init__.py

from .start import start_command
from .help import help_command
from .commands import command_router
from .errors import error_handler
from .auth_handler import check_auth

print("✅ Handlers package loaded.")