# aurora/handlers/errors.py

import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import RPCError

# Set up a dedicated logger for errors
logger = logging.getLogger(__name__)

# Error handler function to catch exceptions in message handlers
@Client.on_message(filters.command(["start", "help", "play", "vplay", "ping", "loop", "speed"]))
async def error_handler(client: Client, message: Message):
    try:
        # Simulate your command logic here
        # In production this would be replaced with actual logic
        raise Exception("Simulated error for demonstration.")

    except Exception as e:
        # Log the error with full stack trace
        logger.error(f"An error occurred: {e}", exc_info=True)

        # Attempt to inform the user
        try:
            await message.reply_text(
                "⚠️ An unexpected error occurred. Please try again later.",
                quote=True
            )
        except RPCError:
            # Fallback in case the message can't be replied to
            pass