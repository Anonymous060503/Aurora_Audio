# aurora/handlers/start.py

from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from config import BOT_NAME, BOT_USERNAME


@Client.on_message(filters.command("start") & filters.private)
async def start_command(client: Client, message: Message):
    try:
        user = message.from_user.first_name or "User"
        start_text = (
            f"👋 Hello {user}!\n\n"
            f"I am **{BOT_NAME}**, your powerful assistant for HD group voice/video playback with real-time control.\n\n"
            "Use the buttons below to navigate through my features and documentation."
        )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📖 Help", callback_data="help_menu"),
                InlineKeyboardButton("🛠 Commands", callback_data="commands_menu")
            ],
            [
                InlineKeyboardButton("👑 Owner", callback_data="owner_info"),
                InlineKeyboardButton("🔐 Roles", callback_data="roles_info")
            ],
            [
                InlineKeyboardButton("➕ Add to Group", url=f"https://t.me/{BOT_USERNAME}?startgroup=true")
            ]
        ])

        await message.reply_text(start_text, reply_markup=keyboard, disable_web_page_preview=True)

    except Exception as e:
        await message.reply_text("❌ Something went wrong while processing your request.")
        print(f"[ERROR - /start] {e}")