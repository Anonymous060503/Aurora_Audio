# aurora/handlers/help.py

from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

HELP_TEXT = """
**📖 Help Menu**

Welcome to the help section! Here's what I can do:

🔹 `/play [song name or URL]` – Stream audio in group  
🔹 `/vplay [video name or URL]` – Stream video in group  
🔹 `/pause` – Pause playback  
🔹 `/resume` – Resume playback  
🔹 `/stop` – Stop playback  
🔹 `/loop [on/off]` – Loop current media  
🔹 `/speed [1.0x / 1.5x / 2x]` – Change playback speed  
🔹 `/auth` – Authorize user  
🔹 `/block` – Block user  
🔹 `/broadcast` – Broadcast a message to all groups

Use the buttons below to jump to a section.
"""

@Client.on_message(filters.command("help") & filters.private)
async def help_command(client: Client, message: Message):
    try:
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔊 Playback", callback_data="help_playback"),
                InlineKeyboardButton("⚙️ Admin", callback_data="help_admin")
            ],
            [
                InlineKeyboardButton("🌀 Looping", callback_data="help_loop"),
                InlineKeyboardButton("⏩ Speed", callback_data="help_speed")
            ],
            [
                InlineKeyboardButton("🔙 Back", callback_data="main_menu")
            ]
        ])

        await message.reply_text(HELP_TEXT, reply_markup=keyboard)

    except Exception as e:
        await message.reply_text("❌ Unable to show help.")
        print(f"[ERROR - /help] {e}")