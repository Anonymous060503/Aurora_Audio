# aurora/handlers/commands.py

from pyrogram import Client, filters
from pyrogram.types import Message

# Command registry dictionary
command_router = {}

def register_command(command: str, description: str):
    """
    Register a command and its description.
    Used for dynamic help menu or debugging.
    """
    command_router[command] = description


@Client.on_message(filters.command("commands") & filters.private)
async def list_commands(client: Client, message: Message):
    """
    /commands handler – Shows all registered commands with descriptions.
    This is auto-updated from all modules registering their commands.
    """
    if not command_router:
        await message.reply_text("❌ No commands registered.")
        return

    text = "**📦 Available Commands:**\n\n"
    for cmd, desc in sorted(command_router.items()):
        text += f"➡️ `{cmd}` – {desc}\n"

    await message.reply_text(text)