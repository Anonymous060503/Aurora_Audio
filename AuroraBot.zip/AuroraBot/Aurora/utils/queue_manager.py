# aurora/utils/queue_manager.py

"""
Handles audio and video playback queues for groups.
Supports enqueue, dequeue, skip, clear, and inspection.
"""

from typing import List, Dict, Optional


class MediaItem:
    def __init__(self, title: str, url: str, requester: str, duration: Optional[str] = None, type_: str = "audio"):
        self.title = title
        self.url = url
        self.requester = requester
        self.duration = duration
        self.type = type_

    def to_dict(self) -> Dict:
        return {
            "title": self.title,
            "url": self.url,
            "requester": self.requester,
            "duration": self.duration,
            "type": self.type
        }


# Group-based queue storage
queue: Dict[int, List[MediaItem]] = {}


def get_queue(chat_id: int) -> List[MediaItem]:
    """
    Returns the current media queue for a group.

    Args:
        chat_id (int): Telegram group chat ID.

    Returns:
        List[MediaItem]: List of queued media.
    """
    return queue.get(chat_id, [])


def add_to_queue(chat_id: int, media: MediaItem):
    """
    Adds a media item to the group queue.

    Args:
        chat_id (int): Telegram group chat ID.
        media (MediaItem): Media item to enqueue.
    """
    if chat_id not in queue:
        queue[chat_id] = []
    queue[chat_id].append(media)


def pop_from_queue(chat_id: int) -> Optional[MediaItem]:
    """
    Removes and returns the first media item in the queue.

    Args:
        chat_id (int): Telegram group chat ID.

    Returns:
        Optional[MediaItem]: The removed media item or None.
    """
    if chat_id in queue and queue[chat_id]:
        return queue[chat_id].pop(0)
    return None


def skip_current(chat_id: int) -> Optional[MediaItem]:
    """
    Skips the currently playing media (same as pop).

    Args:
        chat_id (int): Telegram group chat ID.

    Returns:
        Optional[MediaItem]: The skipped media item or None.
    """
    return pop_from_queue(chat_id)


def clear_queue(chat_id: int):
    """
    Clears the entire queue for a group.

    Args:
        chat_id (int): Telegram group chat ID.
    """
    if chat_id in queue:
        del queue[chat_id]


def is_queue_empty(chat_id: int) -> bool:
    """
    Checks if the queue is empty for a group.

    Args:
        chat_id (int): Telegram group chat ID.

    Returns:
        bool: True if empty, False otherwise.
    """
    return not queue.get(chat_id)


def peek_queue(chat_id: int) -> Optional[MediaItem]:
    """
    Returns the next media item without removing it.

    Args:
        chat_id (int): Telegram group chat ID.

    Returns:
        Optional[MediaItem]: Next media or None.
    """
    q = queue.get(chat_id, [])
    return q[0] if q else None