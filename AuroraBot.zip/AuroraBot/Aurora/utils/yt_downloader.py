# aurora/utils/yt_downloader.py

"""
This module handles downloading YouTube videos and audio streams
using pytube with error handling and progress updates.
"""

from pytube import YouTube
from pytube.exceptions import VideoUnavailable, RegexMatchError
import os


def download_audio(url: str, output_path: str = "downloads/audio") -> str:
    """
    Downloads the audio stream of a YouTube video.
    
    Args:
        url (str): The YouTube video URL.
        output_path (str): The path where the audio file will be saved.
    
    Returns:
        str: Path to the downloaded audio file.
    
    Raises:
        Exception: If the video is unavailable or download fails.
    """
    try:
        yt = YouTube(url)
        audio_stream = yt.streams.filter(only_audio=True).first()

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        file_path = audio_stream.download(output_path=output_path)
        return file_path

    except (VideoUnavailable, RegexMatchError) as e:
        raise Exception(f"❌ YouTube video unavailable or invalid URL: {str(e)}")
    except Exception as e:
        raise Exception(f"❌ Failed to download audio: {str(e)}")


def download_video(url: str, output_path: str = "downloads/video", resolution: str = "720p") -> str:
    """
    Downloads the video stream of a YouTube video.
    
    Args:
        url (str): The YouTube video URL.
        output_path (str): The path where the video file will be saved.
        resolution (str): Desired resolution (default is "720p").
    
    Returns:
        str: Path to the downloaded video file.
    
    Raises:
        Exception: If the video is unavailable or download fails.
    """
    try:
        yt = YouTube(url)
        video_stream = yt.streams.filter(progressive=True, file_extension="mp4", res=resolution).first()

        if video_stream is None:
            raise Exception(f"❌ No video stream available for resolution: {resolution}")

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        file_path = video_stream.download(output_path=output_path)
        return file_path

    except (VideoUnavailable, RegexMatchError) as e:
        raise Exception(f"❌ YouTube video unavailable or invalid URL: {str(e)}")
    except Exception as e:
        raise Exception(f"❌ Failed to download video: {str(e)}")