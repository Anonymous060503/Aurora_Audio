# aurora/utils/ffmpeg_helper.py

"""
This module provides helper functions to interact with FFmpeg for media processing.
Supports audio/video conversion, trimming, merging, and format adjustments.
"""

import os
import subprocess
from typing import Optional


def run_ffmpeg_command(command: list) -> bool:
    """
    Runs an FFmpeg command and handles output.

    Args:
        command (list): List of FFmpeg command arguments.

    Returns:
        bool: True if command runs successfully, else False.
    """
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        if result.returncode != 0:
            print(f"❌ FFmpeg Error:\n{result.stderr}")
            return False

        return True

    except FileNotFoundError:
        print("❌ FFmpeg is not installed or not found in system PATH.")
        return False
    except Exception as e:
        print(f"❌ Unexpected error running FFmpeg: {str(e)}")
        return False


def convert_to_mp3(input_file: str, output_file: Optional[str] = None) -> Optional[str]:
    """
    Converts a media file to MP3 format.

    Args:
        input_file (str): Path to input media file.
        output_file (Optional[str]): Path for output MP3 file.

    Returns:
        Optional[str]: Path to output MP3 if successful, else None.
    """
    if not output_file:
        output_file = os.path.splitext(input_file)[0] + ".mp3"

    command = [
        "ffmpeg", "-y", "-i", input_file,
        "-vn", "-acodec", "libmp3lame", "-q:a", "4", output_file
    ]

    if run_ffmpeg_command(command):
        return output_file
    return None


def trim_audio(input_file: str, start_time: int, duration: int, output_file: Optional[str] = None) -> Optional[str]:
    """
    Trims an audio file from a given start time and duration.

    Args:
        input_file (str): Path to input audio file.
        start_time (int): Start time in seconds.
        duration (int): Duration in seconds.
        output_file (Optional[str]): Path for trimmed output file.

    Returns:
        Optional[str]: Path to trimmed file if successful, else None.
    """
    if not output_file:
        output_file = os.path.splitext(input_file)[0] + "_trimmed.mp3"

    command = [
        "ffmpeg", "-y", "-i", input_file,
        "-ss", str(start_time),
        "-t", str(duration),
        "-acodec", "copy", output_file
    ]

    if run_ffmpeg_command(command):
        return output_file
    return None


def extract_audio_from_video(video_file: str, output_audio_file: Optional[str] = None) -> Optional[str]:
    """
    Extracts audio from a video file.

    Args:
        video_file (str): Path to the input video file.
        output_audio_file (Optional[str]): Path to output audio file.

    Returns:
        Optional[str]: Path to the extracted audio file if successful, else None.
    """
    if not output_audio_file:
        output_audio_file = os.path.splitext(video_file)[0] + ".mp3"

    command = [
        "ffmpeg", "-y", "-i", video_file,
        "-q:a", "0", "-map", "a", output_audio_file
    ]

    if run_ffmpeg_command(command):
        return output_audio_file
    return None