# aurora/utils/validator.py

"""
Validation utilities for user inputs, URLs, file formats, and more.
Ensures data integrity before passing to core handlers.
"""

import re
from urllib.parse import urlparse


# YouTube URL validator (basic support)
YOUTUBE_REGEX = re.compile(
    r'^(https?://)?(www\.)?(youtube\.com|youtu\.be)/.+$'
)

# Supported file extensions
VALID_AUDIO_FORMATS = (".mp3", ".m4a", ".flac", ".wav", ".aac", ".ogg")
VALID_VIDEO_FORMATS = (".mp4", ".mkv", ".webm", ".mov", ".avi")


def is_valid_url(url: str) -> bool:
    """
    Checks if a URL is valid.

    Args:
        url (str): Input URL.

    Returns:
        bool: True if valid, False otherwise.
    """
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except Exception:
        return False


def is_youtube_url(url: str) -> bool:
    """
    Checks if a URL is a valid YouTube link.

    Args:
        url (str): Input URL.

    Returns:
        bool: True if YouTube URL, False otherwise.
    """
    return bool(YOUTUBE_REGEX.match(url))


def is_supported_audio(file_name: str) -> bool:
    """
    Validates audio file extension.

    Args:
        file_name (str): Name of the audio file.

    Returns:
        bool: True if supported format.
    """
    return file_name.lower().endswith(VALID_AUDIO_FORMATS)


def is_supported_video(file_name: str) -> bool:
    """
    Validates video file extension.

    Args:
        file_name (str): Name of the video file.

    Returns:
        bool: True if supported format.
    """
    return file_name.lower().endswith(VALID_VIDEO_FORMATS)


def is_valid_playback_speed(speed: float) -> bool:
    """
    Validates allowed playback speed range.

    Args:
        speed (float): Requested playback speed.

    Returns:
        bool: True if within 0.25x to 3.0x.
    """
    return 0.25 <= speed <= 3.0