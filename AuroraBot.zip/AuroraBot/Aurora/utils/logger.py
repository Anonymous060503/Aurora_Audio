# aurora/utils/logger.py

"""
Centralized logging configuration for AuroraBot.
Handles different log levels and formats for easier debugging and monitoring.
"""

import logging
from logging.handlers import RotatingFileHandler
import os


# Create logs directory if not exists
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)

# Path to log file
LOG_FILE = os.path.join(LOG_DIR, "bot.log")

# Logger configuration
logger = logging.getLogger("AuroraBot")
logger.setLevel(logging.DEBUG)  # Set to INFO or WARNING in production

# Console handler (prints to terminal)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# File handler (rotates logs, 5MB max per file, keep 3 backups)
file_handler = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3)
file_handler.setLevel(logging.DEBUG)

# Log format
formatter = logging.Formatter(
    "[%(asctime)s] [%(levelname)s] - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# Apply format to both handlers
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Add handlers to the logger
logger.addHandler(console_handler)
logger.addHandler(file_handler)


# Shortcut for external use
def get_logger(name: str) -> logging.Logger:
    """
    Returns a child logger with specified name.

    Args:
        name (str): Component or module name.

    Returns:
        logging.Logger: Configured logger instance.
    """
    return logger.getChild(name)