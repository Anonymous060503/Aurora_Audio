# aurora/utils/__init__.py

"""
Utility subpackage initialization for AuroraBot.

This package includes helper modules for:
- Logging
- YouTube downloading
- FFMPEG interactions
- Queue management
- Validation
"""

from .logger import logger

print("✅ Utilities loaded successfully.")