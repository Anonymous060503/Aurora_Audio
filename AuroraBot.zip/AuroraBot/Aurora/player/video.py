"""
Handles video playback using PyTgCalls in Telegram group or channel video chats.
"""

from pytgcalls import PyTgCalls
from pytgcalls.types.input_stream import InputStream, AudioVideoPiped
from pyrogram import Client
from pyrogram.types import Message
import asyncio
import os

from aurora.utils.ffmpeg_helper import convert_video  # Will be implemented
from aurora.utils.logger import log


class VideoPlayer:
    def __init__(self, client: Client, tg_calls: PyTgCalls):
        self.client = client
        self.tg_calls = tg_calls

    async def play_video(self, chat_id: int, video_url: str, message: Message = None):
        """
        Download and play video with audio in the given chat using PyTgCalls.
        """
        try:
            log.info(f"Starting video stream for: {video_url} in chat {chat_id}")

            # Step 1: Convert the input to video+audio stream format
            video_path = await convert_video(video_url)

            # Step 2: Stream via PyTgCalls
            await self.tg_calls.join_group_call(
                chat_id,
                InputStream(
                    AudioVideoPiped(video_path)
                ),
                stream_type="local_stream"
            )

            log.info(f"Video stream started successfully in chat {chat_id}")

            if message:
                await message.reply_text("✅ Video playback started.")

        except Exception as e:
            log.error(f"Failed to play video in chat {chat_id}: {e}")
            if message:
                await message.reply_text("❌ Failed to start video playback.")
        finally:
            # Clean up temp video file
            if os.path.exists("downloads/video.raw"):
                os.remove("downloads/video.raw")

    async def stop_video(self, chat_id: int, message: Message = None):
        """
        Stop video playback and leave the voice chat.
        """
        try:
            await self.tg_calls.leave_group_call(chat_id)
            log.info(f"Video playback stopped in chat {chat_id}")

            if message:
                await message.reply_text("🛑 Video playback stopped.")
        except Exception as e:
            log.error(f"Error stopping video in chat {chat_id}: {e}")
            if message:
                await message.reply_text("❌ Could not stop the video.")