"""
Handles playback speed adjustment logic using ffmpeg filters.
"""

from aurora.utils.ffmpeg_helper import convert_audio_with_speed, convert_video_with_speed
from aurora.utils.logger import log


class SpeedController:
    def __init__(self):
        # Optional: store or fetch speed preferences
        self.default_speed = 1.0  # 1x

    async def set_audio_speed(self, audio_url: str, speed: float) -> str:
        """
        Convert and return path to audio at modified speed.
        """
        try:
            log.info(f"Setting audio speed to {speed}x for: {audio_url}")
            converted_path = await convert_audio_with_speed(audio_url, speed)
            log.info("Audio speed conversion successful.")
            return converted_path
        except Exception as e:
            log.error(f"Failed to convert audio speed: {e}")
            raise

    async def set_video_speed(self, video_url: str, speed: float) -> str:
        """
        Convert and return path to video at modified speed.
        """
        try:
            log.info(f"Setting video speed to {speed}x for: {video_url}")
            converted_path = await convert_video_with_speed(video_url, speed)
            log.info("Video speed conversion successful.")
            return converted_path
        except Exception as e:
            log.error(f"Failed to convert video speed: {e}")
            raise