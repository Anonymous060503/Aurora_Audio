"""
aurora.player package initializer.

This package contains modules for handling audio and video playback,
speed control, and loop handling for the bot.
"""

# Optional: Preload core modules for easier importing elsewhere
from .audio import AudioPlayer
from .video import VideoPlayer
from .speed_control import SpeedController
from .loop_handler import LoopHandler

__all__ = ["AudioPlayer", "VideoPlayer", "SpeedController", "LoopHandler"]