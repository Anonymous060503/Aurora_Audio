"""
Handles looping logic for audio/video playback.
"""

from aurora.database.loop_config import get_loop_status
from aurora.utils.logger import log


class LoopHandler:
    def __init__(self):
        pass

    async def should_loop(self, chat_id: int) -> bool:
        """
        Check from database whether looping is enabled for this chat.
        """
        try:
            loop_enabled = await get_loop_status(chat_id)
            log.info(f"Loop status for chat {chat_id}: {loop_enabled}")
            return loop_enabled
        except Exception as e:
            log.error(f"Error fetching loop status for chat {chat_id}: {e}")
            return False