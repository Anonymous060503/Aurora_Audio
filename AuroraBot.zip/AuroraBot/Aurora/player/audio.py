"""
Handles audio playback using PyTgCalls in Telegram group or channel voice chats.
"""

from pytgcalls import PyTgCalls
from pytgcalls.types.input_stream import InputStream, AudioPiped
from pyrogram.types import Message
from pyrogram import Client
import asyncio
import os

from aurora.utils.ffmpeg_helper import convert_audio  # We'll write this helper
from aurora.utils.logger import log  # Logger wrapper for consistent logs


class AudioPlayer:
    def __init__(self, client: Client, tg_calls: PyTgCalls):
        self.client = client
        self.tg_calls = tg_calls

    async def play_audio(self, chat_id: int, audio_url: str, message: Message = None):
        """
        Download and play audio in the given chat using PyTgCalls.
        """
        try:
            log.info(f"Starting audio stream for: {audio_url} in chat {chat_id}")

            # Step 1: Convert the input audio URL or stream to a raw format for TG call
            audio_path = await convert_audio(audio_url)

            # Step 2: Play using PyTgCalls
            await self.tg_calls.join_group_call(
                chat_id,
                InputStream(
                    AudioPiped(audio_path)
                ),
                stream_type="local_stream"
            )

            log.info(f"Audio stream started successfully in chat {chat_id}")

            if message:
                await message.reply_text("✅ Audio playback started.")

        except Exception as e:
            log.error(f"Failed to play audio in chat {chat_id}: {e}")
            if message:
                await message.reply_text("❌ Failed to start audio playback.")
        finally:
            # Clean up temp audio file
            if os.path.exists("downloads/audio.raw"):
                os.remove("downloads/audio.raw")

    async def stop_audio(self, chat_id: int, message: Message = None):
        """
        Stop audio playback and leave the voice chat.
        """
        try:
            await self.tg_calls.leave_group_call(chat_id)
            log.info(f"Audio playback stopped in chat {chat_id}")

            if message:
                await message.reply_text("🛑 Audio playback stopped.")
        except Exception as e:
            log.error(f"Error stopping audio in chat {chat_id}: {e}")
            if message:
                await message.reply_text("❌ Could not stop the playback.")