import auto_installer
auto_installer.check_and_install()

import os
import logging
from dotenv import load_dotenv
from pyrogram import Client
from pyrogram.errors import RPCError
from aurora.config import Config
from aurora.utils.logger import setup_logger
from aurora.handlers import start, help, commands, errors, auth_handler

# Load .env
load_dotenv()

# Setup logging
setup_logger()

# Bot Client
app = Client(
    name="AuroraBot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    plugins=dict(root="modules")  # Auto-load modules folder
)

@app.on_startup()
async def startup():
    logging.info("🚀 AuroraBot is starting...")
    # DB check or any startup tasks can go here

@app.on_shutdown()
async def shutdown():
    logging.info("🛑 AuroraBot stopped.")

if __name__ == "__main__":
    try:
        logging.info("📡 Connecting to Telegram API...")
        app.run()
    except RPCError as e:
        logging.error(f"Telegram API Error: {e}")
    except Exception as e:
        logging.error(f"Unexpected Error: {e}")