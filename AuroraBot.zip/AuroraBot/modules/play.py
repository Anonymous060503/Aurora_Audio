# modules/play.py

from pyrogram import filters
from pyrogram.types import Message
from aurora.handlers.auth_handler import check_auth
from aurora.player.audio import AudioPlayer
from aurora.utils.validator import validate_url
from aurora.utils.buttons import get_playback_buttons
from aurora.utils.logger import log_command
from config import BOT_USERNAME
from aurora import app

@app.on_message(filters.command("play") & filters.group)
@check_auth  # Ensures only allowed users can execute
async def play_command(client, message: Message):
    """
    Handles the /play command. Plays audio from YouTube or direct URL.
    """
    if len(message.command) < 2:
        return await message.reply_text("❌ Please provide a song name or URL to play.")

    query = " ".join(message.command[1:])
    log_command("play", message)

    try:
        # Validate input
        if not validate_url(query):
            return await message.reply_text("❌ Invalid URL or keyword. Please try again.")

        await message.reply_text("🔄 Processing your request...")

        # Call audio playback
        stream_info = await AudioPlayer.start_stream(message.chat.id, query)

        # Prepare and send response
        caption = f"▶️ Now Playing: **{stream_info['title']}**\n📎 Requested by: {message.from_user.mention}"
        buttons = get_playback_buttons(chat_id=message.chat.id)

        await message.reply_photo(photo=stream_info['thumbnail'], caption=caption, reply_markup=buttons)

    except Exception as e:
        await message.reply_text(f"❌ Failed to play: {e}")