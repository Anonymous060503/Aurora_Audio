# modules/speed.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.handlers.auth_handler import check_auth
from aurora.database.speed_config import set_speed, get_speed
from aurora.utils.logger import log_command

# Supported speeds (you can extend this if ffmpeg/player supports more)
SUPPORTED_SPEEDS = ["0.5x", "1x", "1.5x", "2x"]


@app.on_message(filters.command("speed") & filters.group)
@check_auth
async def speed_command(client, message: Message):
    """
    Controls playback speed of audio/video in group voice chats.
    Usage:
    - /speed -> show current speed
    - /speed [value] -> set speed (e.g., /speed 1.5x)
    """

    log_command("speed", message)
    chat_id = message.chat.id

    # Case: just /speed → show current
    if len(message.command) == 1:
        current_speed = await get_speed(chat_id)
        return await message.reply_text(f"🚀 Current playback speed: **{current_speed}**")

    # Extract and validate speed
    new_speed = message.command[1].lower()

    if new_speed not in SUPPORTED_SPEEDS:
        return await message.reply_text(
            f"❌ Invalid speed.\n\nSupported speeds:\n`{', '.join(SUPPORTED_SPEEDS)}`"
        )

    # Update in DB
    await set_speed(chat_id, new_speed)
    await message.reply_text(f"✅ Playback speed updated to: **{new_speed}**")