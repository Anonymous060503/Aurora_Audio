# modules/broadcast.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.database.broadcast_log import save_broadcast_message
from aurora.handlers.auth_handler import is_admin
from aurora.utils.logger import log_command
from aurora.database.whitelist import get_whitelisted_chats

@app.on_message(filters.command("broadcast") & filters.private)
async def broadcast_message(client, message: Message):
    """
    Broadcast a message to all whitelisted groups.
    Usage: /broadcast Your message here
    """
    log_command("broadcast", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    if len(message.command) < 2:
        return await message.reply("⚠️ Please provide a message to broadcast.\n\n**Example:** `/broadcast Hello everyone!`")

    broadcast_text = message.text.split(None, 1)[1].strip()

    chats = await get_whitelisted_chats()
    if not chats:
        return await message.reply("⚠️ No whitelisted chats found to broadcast.")

    success = 0
    fail = 0

    for chat_id in chats:
        try:
            await app.send_message(chat_id, broadcast_text)
            success += 1
        except Exception:
            fail += 1

    await save_broadcast_message(message.from_user.id, broadcast_text, success, fail)

    await message.reply(
        f"📢 Broadcast complete.\n\n✅ Success: {success}\n❌ Failed: {fail}"
    )