# modules/stopcast.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.database.whitelist import get_whitelisted_chats
from aurora.handlers.auth_handler import is_admin
from aurora.utils.logger import log_command

@app.on_message(filters.command("stopcast") & filters.private)
async def stop_broadcast(client, message: Message):
    """
    Send a stop message to all whitelisted groups to end any ongoing broadcast.
    Usage: /stopcast
    """
    log_command("stopcast", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    chats = await get_whitelisted_chats()
    if not chats:
        return await message.reply("⚠️ No whitelisted chats found.")

    stop_text = "⛔️ The broadcast has been stopped by an admin."

    success = 0
    fail = 0

    for chat_id in chats:
        try:
            await app.send_message(chat_id, stop_text)
            success += 1
        except Exception:
            fail += 1

    await message.reply(
        f"🛑 Stopcast complete.\n\n✅ Sent to: {success} chats\n❌ Failed in: {fail} chats"
    )