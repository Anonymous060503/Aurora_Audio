# modules/__init__.py

"""
Initializes the modules package.
Each module here corresponds to a bot command or feature.
"""

print("✅ Modules package loaded.")