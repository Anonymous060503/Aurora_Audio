# modules/whitelist.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.database.whitelist import add_whitelist_chat, remove_whitelist_chat, get_whitelisted_chats
from aurora.handlers.auth_handler import is_admin
from aurora.utils.logger import log_command

@app.on_message(filters.command("whitelist") & filters.private)
async def whitelist_chat(client, message: Message):
    """
    Add a group chat to the whitelist.
    Usage: /whitelist [chat_id or chat_link]
    """
    log_command("whitelist", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    if len(message.command) < 2:
        return await message.reply("⚠️ Please provide a chat ID or invite link.\n\n**Example:** `/whitelist -1001234567890`")

    chat_identifier = message.text.split(None, 1)[1].strip()

    try:
        await add_whitelist_chat(chat_identifier)
        await message.reply(f"✅ Successfully whitelisted chat: `{chat_identifier}`")
    except Exception as e:
        await message.reply(f"❌ Failed to whitelist chat.\n**Error:** `{str(e)}`")


@app.on_message(filters.command("whitelistchats") & filters.private)
async def list_whitelisted_chats(client, message: Message):
    """
    List all whitelisted group chats.
    Usage: /whitelistchats
    """
    log_command("whitelistchats", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    chats = await get_whitelisted_chats()

    if not chats:
        return await message.reply("✅ No whitelisted chats found.")

    text = "✅ **Whitelisted Chats:**\n\n"
    for cid in chats:
        text += f"• `{cid}`\n"

    await message.reply(text)


@app.on_message(filters.command("unwhitelist") & filters.private)
async def remove_from_whitelist(client, message: Message):
    """
    Remove a chat from whitelist.
    Usage: /unwhitelist [chat_id or chat_link]
    """
    log_command("unwhitelist", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    if len(message.command) < 2:
        return await message.reply("⚠️ Please provide a chat ID or invite link.\n\n**Example:** `/unwhitelist -1001234567890`")

    chat_identifier = message.text.split(None, 1)[1].strip()

    try:
        await remove_whitelist_chat(chat_identifier)
        await message.reply(f"🗑️ Successfully removed chat from whitelist: `{chat_identifier}`")
    except Exception as e:
        await message.reply(f"❌ Failed to remove chat.\n**Error:** `{str(e)}`")