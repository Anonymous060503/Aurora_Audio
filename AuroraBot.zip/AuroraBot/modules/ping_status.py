# modules/ping_status.py

import time
import platform
import psutil
from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.utils.logger import log_command

def get_uptime():
    seconds = time.time() - psutil.boot_time()
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    return f"{int(days)}d {int(hours)}h {int(minutes)}m {int(seconds)}s"

@app.on_message(filters.command("ping") & filters.private)
async def ping_command(_, message: Message):
    """
    Responds to /ping command with bot status, latency, uptime and system info.
    """
    log_command("ping", message)

    start = time.time()
    response = await message.reply("🏓 Pinging...")
    end = time.time()

    latency = round((end - start) * 1000, 2)
    uptime = get_uptime()

    cpu = psutil.cpu_percent(interval=0.5)
    ram = psutil.virtual_memory().percent
    system = platform.system()
    arch = platform.machine()
    py_version = platform.python_version()

    text = (
        f"✅ **Bot is Online!**\n\n"
        f"📡 **Latency:** `{latency} ms`\n"
        f"⏱️ **Uptime:** `{uptime}`\n"
        f"🧠 **CPU Usage:** `{cpu}%`\n"
        f"💾 **RAM Usage:** `{ram}%`\n"
        f"🖥️ **System:** `{system} {arch}`\n"
        f"🐍 **Python:** `{py_version}`"
    )

    await response.edit(text)