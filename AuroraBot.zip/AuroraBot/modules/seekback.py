# modules/seekback.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.handlers.auth_handler import check_auth
from aurora.player.audio import AudioPlayer
from aurora.player.video import VideoPlayer
from aurora.utils.logger import log_command


@app.on_message(filters.command("seekback") & filters.group)
@check_auth
async def seekback_command(client, message: Message):
    """
    Seeks backward in the currently playing stream by a given number of seconds.
    Usage: /seekback 30 → Rewinds 30 seconds
    """
    log_command("seekback", message)

    if len(message.command) != 2 or not message.command[1].isdigit():
        return await message.reply_text("❌ Usage: /seekback <seconds>")

    seconds = int(message.command[1])

    try:
        # Try seeking back in audio stream
        success = await AudioPlayer.seek_backward(message.chat.id, seconds)
        if success:
            return await message.reply_text(f"⏪ Rewound **{seconds} seconds** in audio stream.")

        # Try seeking back in video stream
        success = await VideoPlayer.seek_backward(message.chat.id, seconds)
        if success:
            return await message.reply_text(f"⏪ Rewound **{seconds} seconds** in video stream.")

        await message.reply_text("⚠️ No active stream found to rewind.")

    except Exception as e:
        await message.reply_text(f"❌ Failed to rewind: {e}")