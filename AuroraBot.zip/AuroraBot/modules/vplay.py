# modules/vplay.py

from pyrogram import filters
from pyrogram.types import Message
from aurora.handlers.auth_handler import check_auth
from aurora.player.video import VideoPlayer
from aurora.utils.validator import validate_url
from aurora.utils.buttons import get_playback_buttons
from aurora.utils.logger import log_command
from config import BOT_USERNAME
from aurora import app

@app.on_message(filters.command("vplay") & filters.group)
@check_auth  # Allow only authorized users
async def vplay_command(client, message: Message):
    """
    Handles the /vplay command to play video streams in group voice chat.
    """
    if len(message.command) < 2:
        return await message.reply_text("❌ Please provide a video name or URL to play.")

    query = " ".join(message.command[1:])
    log_command("vplay", message)

    try:
        if not validate_url(query):
            return await message.reply_text("❌ Invalid video URL or keyword.")

        await message.reply_text("🔄 Fetching video stream...")

        # Call video playback logic
        stream_info = await VideoPlayer.start_video_stream(message.chat.id, query)

        # Send confirmation with video title, thumbnail, and buttons
        caption = f"🎬 Now Playing: **{stream_info['title']}**\n📎 Requested by: {message.from_user.mention}"
        buttons = get_playback_buttons(chat_id=message.chat.id)

        await message.reply_photo(photo=stream_info['thumbnail'], caption=caption, reply_markup=buttons)

    except Exception as e:
        await message.reply_text(f"❌ Failed to play video: {e}")