# modules/block.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.database.blocklist import add_blocked_user, remove_blocked_user, get_blocked_users
from aurora.handlers.auth_handler import is_admin
from aurora.utils.logger import log_command

@app.on_message(filters.command("block") & filters.group)
async def block_user(client, message: Message):
    """
    Block a user from using the bot.
    Usage: /block [reply to user]
    """
    log_command("block", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    if not message.reply_to_message:
        return await message.reply("❗ Please reply to the user you want to block.")

    user = message.reply_to_message.from_user

    await add_blocked_user(user.id)
    await message.reply(f"🚫 Blocked {user.mention} from using the bot.")

@app.on_message(filters.command("unblock") & filters.group)
async def unblock_user(client, message: Message):
    """
    Unblock a previously blocked user.
    Usage: /unblock [reply to user]
    """
    log_command("unblock", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    if not message.reply_to_message:
        return await message.reply("❗ Please reply to the user you want to unblock.")

    user = message.reply_to_message.from_user

    await remove_blocked_user(user.id)
    await message.reply(f"✅ Unblocked {user.mention}.")

@app.on_message(filters.command("blocklists") & filters.group)
async def list_blocked_users(client, message: Message):
    """
    List all blocked users.
    Usage: /blocklists
    """
    log_command("blocklists", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    blocked_users = await get_blocked_users()

    if not blocked_users:
        return await message.reply("✅ No users are currently blocked.")

    text = "🚫 **Blocked Users:**\n\n"
    for user_id in blocked_users:
        text += f"• `{user_id}`\n"

    await message.reply(text)