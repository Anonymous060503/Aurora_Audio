# modules/loop.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.handlers.auth_handler import check_auth
from aurora.database.loop_config import set_loop, get_loop
from aurora.utils.logger import log_command


@app.on_message(filters.command("loop") & filters.group)
@check_auth
async def loop_command(client, message: Message):
    """
    Enables or disables looping of the current stream.
    Usage:
    - /loop on
    - /loop off
    - /loop (to check current status)
    """
    log_command("loop", message)

    chat_id = message.chat.id

    if len(message.command) == 1:
        # Show current loop status
        is_looping = await get_loop(chat_id)
        status = "🔁 Enabled" if is_looping else "⏹️ Disabled"
        return await message.reply_text(f"🔄 Loop status: **{status}**")

    option = message.command[1].lower()

    if option not in ["on", "off"]:
        return await message.reply_text("❌ Usage: /loop [on/off]")

    loop_enabled = option == "on"
    await set_loop(chat_id, loop_enabled)

    status = "enabled ✅" if loop_enabled else "disabled ❌"
    await message.reply_text(f"🔄 Looping has been **{status}**.")