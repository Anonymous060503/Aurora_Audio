# modules/seek.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.handlers.auth_handler import check_auth
from aurora.player.audio import AudioPlayer
from aurora.player.video import VideoPlayer
from aurora.utils.logger import log_command


@app.on_message(filters.command("seek") & filters.group)
@check_auth
async def seek_command(client, message: Message):
    """
    Seeks forward in the currently playing stream by a given number of seconds.
    Usage: /seek 30 → Seeks forward 30 seconds
    """
    log_command("seek", message)

    if len(message.command) != 2 or not message.command[1].isdigit():
        return await message.reply_text("❌ Usage: /seek <seconds>")

    seconds = int(message.command[1])

    try:
        # Try seeking in audio stream
        success = await AudioPlayer.seek_forward(message.chat.id, seconds)
        if success:
            return await message.reply_text(f"⏩ Skipped forward **{seconds} seconds** in audio stream.")

        # If audio stream not active, try video stream
        success = await VideoPlayer.seek_forward(message.chat.id, seconds)
        if success:
            return await message.reply_text(f"⏩ Skipped forward **{seconds} seconds** in video stream.")

        # If neither audio nor video is active
        await message.reply_text("⚠️ No active stream found to seek.")

    except Exception as e:
        await message.reply_text(f"❌ Failed to seek: {e}")