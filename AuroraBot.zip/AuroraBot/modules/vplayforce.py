# modules/vplayforce.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.handlers.auth_handler import check_auth
from aurora.player.video import VideoPlayer
from aurora.utils.validator import validate_url
from aurora.utils.buttons import get_playback_buttons
from aurora.utils.logger import log_command


@app.on_message(filters.command("vplayforce") & filters.group)
@check_auth  # Checks if the user is authorized to run this command
async def vplayforce_command(client, message: Message):
    """
    Forcefully starts a new video stream, replacing the existing one if active.
    """
    if len(message.command) < 2:
        return await message.reply_text("❌ Please provide a video name or URL to play.")

    query = " ".join(message.command[1:])
    log_command("vplayforce", message)

    try:
        if not validate_url(query):
            return await message.reply_text("❌ Invalid video URL or keyword.")

        await message.reply_text("🔄 Forcing new video stream...")

        # Forcefully start the video stream
        stream_info = await VideoPlayer.start_video_stream(
            chat_id=message.chat.id,
            query=query,
            force=True  # This will override any active stream
        )

        caption = f"🎬 Now Playing (Forced): **{stream_info['title']}**\n📎 Requested by: {message.from_user.mention}"
        buttons = get_playback_buttons(chat_id=message.chat.id)

        await message.reply_photo(photo=stream_info['thumbnail'], caption=caption, reply_markup=buttons)

    except Exception as e:
        await message.reply_text(f"❌ Failed to play video: {e}")