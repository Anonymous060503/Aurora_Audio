# modules/auth.py

from pyrogram import filters
from pyrogram.types import Message
from aurora import app
from aurora.database.auth_users import add_user, remove_user, get_auth_users
from aurora.handlers.auth_handler import is_admin
from aurora.utils.logger import log_command

@app.on_message(filters.command(["auth", "authorize"]) & filters.group)
async def authorize_user(client, message: Message):
    """
    Authorize a user to access admin commands.
    Usage: /auth [reply to user]
    """
    log_command("auth", message)
    
    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")
    
    if not message.reply_to_message:
        return await message.reply("❗ Please reply to the user you want to authorize.")

    user = message.reply_to_message.from_user
    chat_id = message.chat.id

    await add_user(chat_id, user.id)
    await message.reply(f"✅ Authorized {user.mention} to use admin commands.")

@app.on_message(filters.command(["unauth", "revoke"]) & filters.group)
async def unauthorize_user(client, message: Message):
    """
    Remove a user's admin access.
    Usage: /unauth [reply to user]
    """
    log_command("unauth", message)

    if not await is_admin(message):
        return await message.reply("❌ You are not authorized to perform this action.")

    if not message.reply_to_message:
        return await message.reply("❗ Please reply to the user you want to unauthorize.")

    user = message.reply_to_message.from_user
    chat_id = message.chat.id

    await remove_user(chat_id, user.id)
    await message.reply(f"🚫 Revoked admin access for {user.mention}.")

@app.on_message(filters.command("authlist") & filters.group)
async def list_authorized_users(client, message: Message):
    """
    List all authorized users in the group.
    Usage: /authlist
    """
    log_command("authlist", message)

    chat_id = message.chat.id
    users = await get_auth_users(chat_id)

    if not users:
        return await message.reply("📛 No users are currently authorized.")

    text = "🔐 **Authorized Users:**\n\n"
    for user_id in users:
        text += f"• `{user_id}`\n"

    await message.reply(text)