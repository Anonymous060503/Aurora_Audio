#!/bin/bash
set -e

echo "==============================="
echo " 🚀 Starting AuroraBot "
echo "==============================="

# 1. Check Python version
PYTHON_VERSION=$(python3 -V 2>&1 | awk '{print $2}')
echo "📝 Python Version: $PYTHON_VERSION"

# 2. Create virtual environment if not exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# 3. Activate virtual environment
source venv/bin/activate

# 4. Upgrade pip
echo "⬆️  Upgrading pip..."
pip install --upgrade pip

# 5. Install dependencies from requirements.txt
if [ -f "requirements.txt" ]; then
    echo "📥 Installing dependencies..."
    pip install -r requirements.txt
else
    echo "⚠️  requirements.txt not found!"
fi

# 6. Export environment variables from .env (optional)
if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs)
    echo "✅ Environment variables loaded."
else
    echo "⚠️  .env file not found!"
fi

# 7. Start the bot
echo "▶️  Running AuroraBot..."
python3 run.py