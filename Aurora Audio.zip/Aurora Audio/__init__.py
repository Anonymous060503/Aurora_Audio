# Bot folder/module initializer
from . import config